import cv2
import numpy as np
import os

# 设置输入和输出的根目录
input_root = r'test'  # 输入图像的根目录
output_root = r'output'  # 输出图像的根目录

# 创建输出根目录
if not os.path.exists(output_root):
    os.makedirs(output_root)


def process_image(image_path, output_image_path):
    """处理单张图片，并保存"""
    # 读取图像并转换为灰度图
    image = cv2.imread(image_path, cv2.IMREAD_UNCHANGED)

    # 二值化图像，将感兴趣的区域设置为白色
    _, binary_image = cv2.threshold(image, 200, 255, cv2.THRESH_BINARY)

    # 使用连通组件分析进行区域标记
    num_labels, labels_im = cv2.connectedComponents(binary_image.astype(np.uint8))

    # 初始化变量以存储每个区域的标签和面积
    area_list = []

    # 计算每个区域的面积并记录
    for label in range(1, num_labels):  # 从1开始，0是背景
        area = np.sum(labels_im == label)
        area_list.append((label, area))

    # 根据区域数量决定保留的区域
    if len(area_list) <= 3:
        # 当区域数量小于等于3时，保留前两个最大区域
        area_list.sort(key=lambda x: x[1], reverse=True)
        top_labels = [label for label, _ in area_list[:2]]
    else:
        # 当区域数量大于3时，保留前三大区域
        area_list.sort(key=lambda x: x[1], reverse=True)
        top_labels = [label for label, _ in area_list[:3]]

    # 创建输出图像，只保留选定的最大区域
    output_image = np.zeros_like(binary_image)
    for label in top_labels:
        output_image[labels_im == label] = 255  # 将最大区域设置为白色

    # 保存处理后的图像到输出路径
    cv2.imwrite(output_image_path, output_image)


def process_directory(input_dir, output_dir):
    """递归处理目录中的所有图片，并将处理结果保存到对应的输出目录"""
    # 创建输出目录
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # 遍历输入目录中的文件和文件夹
    for item in os.listdir(input_dir):
        input_path = os.path.join(input_dir, item)
        output_path = os.path.join(output_dir, item)

        if os.path.isdir(input_path):
            # 如果是文件夹，递归处理
            process_directory(input_path, output_path)
        elif input_path.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff')):
            # 如果是图片文件，处理并保存
            process_image(input_path, output_path)
            #print(f"处理并保存图像: {input_path} 到 {output_path}")


# 开始处理整个根目录下的所有文件夹和图像
process_directory(input_root, output_root)

print("所有图像处理完成并保存到对应的目录中。")
