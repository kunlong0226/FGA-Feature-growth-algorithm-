import cv2
import numpy as np
import os

# 设置输入和输出文件夹路径
input_folder = 'data_after1'  # 输入的大文件夹路径
output_folder = 'trial4'  # 输出文件夹路径

# 创建输出文件夹，如果不存在
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# 遍历大文件夹下的所有子文件夹
for root, dirs, files in os.walk(input_folder):
    for file in files:
        file_path = os.path.join(root, file)

        # 判断文件是否为图片文件（可以根据实际需求扩展文件格式）
        if file.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff')):
            # 读取原始图像
            image = cv2.imread(file_path, 0)  # 以灰度图读取

            # 找到所有连通区域
            contours, _ = cv2.findContours(image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            # 计算每个连通区域的面积
            contour_areas = [cv2.contourArea(c) for c in contours]

            if contour_areas:  # 如果存在连通域
                # 找到面积最大的连通区域
                max_area_idx = np.argmax(contour_areas)
                largest_contour = contours[max_area_idx]

                # 创建一个掩膜，仅绘制最大连通域
                mask = np.zeros_like(image)
                cv2.drawContours(mask, [largest_contour], -1, 255, thickness=cv2.FILLED)

                # 对最大连通域区域进行形态学操作（如膨胀 + 闭运算）
                kernel = np.ones((3, 3), np.uint8)
                dilated_image = cv2.dilate(image, kernel, iterations=1)
                closed_image = cv2.morphologyEx(dilated_image, cv2.MORPH_CLOSE, kernel, iterations=1)

                # 仅对原图中最大连通域区域应用填充
                filled_image = cv2.bitwise_and(closed_image, mask)

                # 合并填充区域与原始图像，仅对最大连通域的区域进行更新
                final_result = cv2.bitwise_or(image, filled_image)

                # 获取相对路径，保持文件夹结构
                relative_path = os.path.relpath(root, input_folder)
                output_subfolder = os.path.join(output_folder, relative_path)

                # 创建对应的子文件夹
                if not os.path.exists(output_subfolder):
                    os.makedirs(output_subfolder)

                # 保存处理后的图片
                output_file_path = os.path.join(output_subfolder, file)
                cv2.imwrite(output_file_path, final_result)

print("处理完成，所有图片已保存到指定文件夹。")
