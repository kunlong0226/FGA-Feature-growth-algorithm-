import cv2
import os
import matplotlib.pyplot as plt

# 设置输入和输出的根目录
input_root = r'data'  # 替换为你自己的数据集路径
output_root = r'data_after1'  # 输出目录

# 检查输出目录是否存在，如果不存在则创建
if not os.path.exists(output_root):
    os.makedirs(output_root)

# 遍历9个类别的子文件夹
for folder_name in os.listdir(input_root):
    input_folder_path = os.path.join(input_root, folder_name)
    output_folder_path = os.path.join(output_root, folder_name)

    # 检查输出子文件夹是否存在，不存在则创建
    if not os.path.exists(output_folder_path):
        os.makedirs(output_folder_path)

    # 遍历每个子文件夹中的所有图像
    for image_name in os.listdir(input_folder_path):
        # 读取图像
        image_path = os.path.join(input_folder_path, image_name)
        image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
        threshold = 150
        image[image<threshold]=0
        image[image>threshold]=255
        # 生成输出图像路径
        output_image_path = os.path.join(output_folder_path, image_name)

        # 保存去噪后的图像
        cv2.imwrite(output_image_path,image)

        #print(f"Processed and saved: {output_image_path}")

print("所有图像已处理并保存到对应的文件夹中。")
