import cv2
import numpy as np
import os


def load_image(image_path):
    """加载输入图像"""
    image_path = os.path.normpath(image_path)  # 规范化路径
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"Cannot load image: {image_path}")
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise FileNotFoundError(f"Cannot load image: {image_path}")
    return image


def save_image(output_image, output_path):
    """保存输出图像"""
    output_path = os.path.normpath(output_path)  # 规范化路径
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    cv2.imwrite(output_path, output_image)


def compute_gradient(image):
    """计算图像的梯度幅值和相位角"""
    sobel_x = cv2.Sobel(image, cv2.CV_64F, 1, 0, ksize=3)
    sobel_y = cv2.Sobel(image, cv2.CV_64F, 0, 1, ksize=3)
    magnitude = cv2.magnitude(sobel_x, sobel_y)
    angle = cv2.phase(sobel_x, sobel_y, angleInDegrees=True)
    return magnitude, angle


def find_connected_components(image):
    """识别连通域"""
    num_labels, labels = cv2.connectedComponents(image, connectivity=4)  # 四连通
    return labels  # 只返回标签矩阵



def get_boundary_points(labels, image):
    """获取每个连通域的边界点，修改为四连通"""
    boundary_points = {}
    rows, cols = image.shape
    for y in range(1, rows - 1):
        for x in range(1, cols - 1):
            if image[y, x] == 255:  # 边缘像素
                component = labels[y, x]
                if component not in boundary_points:
                    boundary_points[component] = []
                boundary_points[component].append((x, y))
    return boundary_points


def calculate_membership(magnitude, angle, px, py, candidate_points, w=0.4):
    """计算候选点的隶属度"""
    memberships = []
    for cx, cy in candidate_points:
        mag_diff = np.abs(magnitude[py, px] - magnitude[cy, cx])
        angle_diff = np.abs(angle[py, px] - angle[cy, cx])
        membership_mag = np.exp(-3 * (mag_diff ** 2))
        membership_angle = np.exp(-3 * (angle_diff ** 2))
        membership = w * membership_mag + (1 - w) * membership_angle
        memberships.append((membership, (cx, cy)))
    return memberships


def get_area_of_component(labels, component):
    """计算给定连通域的面积"""
    return np.sum(labels == component)


def edge_growth_v7(original_image, labels, gradient_magnitude, gradient_angle, max_iterations=10, threshold=0.5,
                   max_connections=3, distance_threshold=10, angle_threshold=15, area_threshold=40, x_distance_threshold=5):
    """边缘生长算法，基于连通域选择端点，限制每个连通域最多与两个其他连通域连接，并加入角度、面积和水平距离限制"""
    # 获取所有连通域的边界点
    boundary_points = get_boundary_points(labels, original_image)
    connections = {component: 0 for component in boundary_points}  # 跟踪每个连通域的连接次数

    # 获取每个连通域的面积
    areas = {component: get_area_of_component(labels, component) for component in boundary_points}

    for iteration in range(max_iterations):
        updated = False
        # 遍历每个连通域
        for component, points in boundary_points.items():
            if connections[component] >= max_connections or areas[component] > area_threshold:
                continue  # 如果该连通域已经连接了两个其他连通域，或者面积超过阈值，则跳过

            for px, py in points:
                # 搜索其他连通域的边界点并计算距离
                candidate_points = []
                for other_component, other_points in boundary_points.items():
                    if other_component != component and connections[other_component] < max_connections and areas[
                        other_component] <= area_threshold:
                        for cx, cy in other_points:
                            # 计算水平距离（x轴差异）
                            x_distance = np.abs(px - cx)
                            if x_distance > x_distance_threshold:
                                continue  # 如果水平距离大于阈值，跳过连接

                            # 计算欧几里得距离和梯度方向差异
                            distance = np.sqrt((px - cx) ** 2 + (py - cy) ** 2)
                            angle_diff = np.abs(gradient_angle[py, px] - gradient_angle[cy, cx])
                            if distance < distance_threshold and angle_diff < angle_threshold:  # 距离和角度阈值检查
                                candidate_points.append((cx, cy, distance, angle_diff, other_component))

                if candidate_points:
                    # 按照距离排序，选择最接近的点
                    candidate_points.sort(key=lambda x: (x[2], x[3]))  # 按照距离和角度排序

                    # 选择距离最近且角度最接近的点
                    best_point = candidate_points[0]
                    bx, by, _, _, best_component = best_point

                    # 计算候选点的隶属度
                    memberships = calculate_membership(gradient_magnitude, gradient_angle, px, py, [(bx, by)])
                    best_membership, _ = max(memberships, key=lambda x: x[0])

                    if best_membership > threshold:
                        cv2.line(original_image, (px, py), (bx, by), 255, 1)
                        connections[component] += 1
                        connections[best_component] += 1
                        updated = True

        if not updated:
            break

    return original_image


def process_directory(input_directory, output_directory):
    """处理指定目录下所有文件夹中的图像，并将结果保存到指定文件夹"""
    for folder_name in os.listdir(input_directory):
        folder_path = os.path.join(input_directory, folder_name)
        if os.path.isdir(folder_path):  # 确保是文件夹
            for image_name in os.listdir(folder_path):
                image_path = os.path.join(folder_path, image_name)
                if os.path.isfile(image_path) and image_name.lower().endswith(('.png', '.jpg', '.jpeg')):

                    # 加载图像
                    original_image = load_image(image_path)

                    # 连通域分析，四连通
                    labels = find_connected_components(original_image)  # 获取标签矩阵

                    # 计算梯度幅值和相位角
                    gradient_magnitude, gradient_angle = compute_gradient(original_image)

                    # 执行 Edge Growth
                    recovered_edges = edge_growth_v7(original_image.copy(), labels, gradient_magnitude, gradient_angle)

                    # 保存最终结果
                    output_image_path = os.path.join(output_directory, folder_name, image_name)
                    save_image(recovered_edges, output_image_path)


def main():
    # 输入和输出文件夹路径
    input_directory = r"test"  # 替换为你的大文件夹路径
    output_directory = r"output"  # 替换为你的结果保存路径

    # 处理所有图像
    process_directory(input_directory, output_directory)
    print("所有图像处理完成！")


if __name__ == "__main__":
    main()